## Requirements

No requirements.

## Providers

| Name | Version |
|------|---------|
| <a name="provider_azurerm"></a> [azurerm](#provider\_azurerm) | n/a |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [azurerm_storage_account.this](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/storage_account) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_allow_nested_items_to_be_public"></a> [allow\_nested\_items\_to\_be\_public](#input\_allow\_nested\_items\_to\_be\_public) | n/a | `bool` | `false` | no |
| <a name="input_application_name"></a> [application\_name](#input\_application\_name) | (Required) Application Name | `string` | n/a | yes |
| <a name="input_environment"></a> [environment](#input\_environment) | (Required) Which Enviornment is this resource deployed | `string` | n/a | yes |
| <a name="input_location"></a> [location](#input\_location) | (Required) Azure Region and Code | <pre>object({<br>    azure_region  = string<br>    location_code = string<br>  })</pre> | n/a | yes |
| <a name="input_resource_group_name"></a> [resource\_group\_name](#input\_resource\_group\_name) | (Required) Azure Resource Group Name | `string` | n/a | yes |
| <a name="input_tags"></a> [tags](#input\_tags) | (Required) Azure Tags | `any` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_id"></a> [id](#output\_id) | The ID of the Storage Account |
| <a name="output_name"></a> [name](#output\_name) | The name of the Storage Account |
