## Requirements

No requirements.

## Providers

| Name | Version |
|------|---------|
| <a name="provider_azurerm"></a> [azurerm](#provider\_azurerm) | n/a |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [azurerm_route_table.this](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/route_table) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_fw_private_ip"></a> [fw\_private\_ip](#input\_fw\_private\_ip) | Firewall private IP | `string` | n/a | yes |
| <a name="input_location"></a> [location](#input\_location) | Location where RouteTable will be deployed | `string` | n/a | yes |
| <a name="input_r_name"></a> [r\_name](#input\_r\_name) | Route name | `string` | n/a | yes |
| <a name="input_resource_group_name"></a> [resource\_group\_name](#input\_resource\_group\_name) | Resource group where RouteTable will be deployed | `string` | n/a | yes |
| <a name="input_rt_name"></a> [rt\_name](#input\_rt\_name) | RouteTable name | `string` | n/a | yes |
| <a name="input_subnet_id"></a> [subnet\_id](#input\_subnet\_id) | AKS subnet ID | `string` | n/a | yes |
| <a name="input_tags"></a> [tags](#input\_tags) | Tags to Apply | `map(string)` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_id"></a> [id](#output\_id) | The Route Table ID. |
| <a name="output_name"></a> [name](#output\_name) | The Route Table name. |
