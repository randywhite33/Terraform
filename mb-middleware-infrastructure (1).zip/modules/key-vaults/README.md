## Requirements

No requirements.

## Providers

| Name | Version |
|------|---------|
| <a name="provider_azurerm"></a> [azurerm](#provider\_azurerm) | n/a |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [azurerm_key_vault.this](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/key_vault) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_application_name"></a> [application\_name](#input\_application\_name) | (Required) Application Name | `string` | n/a | yes |
| <a name="input_enabled_for_disk_encryption"></a> [enabled\_for\_disk\_encryption](#input\_enabled\_for\_disk\_encryption) | (Bool) Should Azure Disk Encryption be permitted to retrieve secrets from the vault and unwrap keys? | `bool` | n/a | yes |
| <a name="input_environment"></a> [environment](#input\_environment) | (Required) Which Enviornment is this resource deployed | `string` | n/a | yes |
| <a name="input_location"></a> [location](#input\_location) | (Required) Azure Region and Code | <pre>object({<br>    azure_region  = string<br>    location_code = string<br>  })</pre> | n/a | yes |
| <a name="input_public_network_access_enabled"></a> [public\_network\_access\_enabled](#input\_public\_network\_access\_enabled) | (Bool) Set to true if external access is required. False otherwise. For backwards compatibility, the default is true. Setting to false without network rules will allow access only via Private Endpoint. Setting to false with network rules will allow access only from specified IP ranges. | `bool` | `true` | no |
| <a name="input_purge_protection_enabled"></a> [purge\_protection\_enabled](#input\_purge\_protection\_enabled) | (Bool) Should Purge Protection be enabled for this Key Vault? Once Purge Protection has been Enabled it's not possible to Disable it. | `bool` | n/a | yes |
| <a name="input_resource_group_name"></a> [resource\_group\_name](#input\_resource\_group\_name) | (Required) Azure Resource Group Name | `string` | n/a | yes |
| <a name="input_sku"></a> [sku](#input\_sku) | (Required) The Name of the SKU used for this Key Vault. Possible values are standard and premium. | `string` | n/a | yes |
| <a name="input_tags"></a> [tags](#input\_tags) | (Required) Azure Tags | `any` | n/a | yes |
| <a name="input_tenant_id"></a> [tenant\_id](#input\_tenant\_id) | (Required) Azure Tenant ID | `string` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_id"></a> [id](#output\_id) | outputs the id formatted |
| <a name="output_name"></a> [name](#output\_name) | outputs the name formatted |
