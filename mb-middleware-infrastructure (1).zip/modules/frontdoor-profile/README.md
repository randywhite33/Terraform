## Requirements

No requirements.

## Providers

| Name | Version |
|------|---------|
| <a name="provider_azurerm"></a> [azurerm](#provider\_azurerm) | 3.80.0 |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [azurerm_cdn_frontdoor_profile.this](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/cdn_frontdoor_profile) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_name"></a> [name](#input\_name) | Specifies the name of the Front Door Profile. Changing this forces a new resource to be created. | `string` | n/a | yes |
| <a name="input_resource_group_name"></a> [resource\_group\_name](#input\_resource\_group\_name) | The name of the Resource Group where this Front Door Profile should exist. Changing this forces a new resource to be created. | `string` | n/a | yes |
| <a name="input_response_timeout_seconds"></a> [response\_timeout\_seconds](#input\_response\_timeout\_seconds) | Specifies the maximum response timeout in seconds. Possible values are between 16 and 240 seconds (inclusive). Defaults to 120 seconds. | `string` | `"120"` | no |
| <a name="input_sku_name"></a> [sku\_name](#input\_sku\_name) | Specifies the SKU for this Front Door Profile. Possible values include Standard\_AzureFrontDoor and Premium\_AzureFrontDoor. Changing this forces a new resource to be created. Defaults to Premium\_AzureFrontDoor. | `string` | `"Premium_AzureFrontDoor"` | no |
| <a name="input_tags"></a> [tags](#input\_tags) | Specifies a mapping of tags to assign to the resource. | `map(string)` | `{}` | no |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_id"></a> [id](#output\_id) | The ID of this Front Door Profile. |
| <a name="output_name"></a> [name](#output\_name) | The name of the Front Door Profile. |
| <a name="output_resource_group_name"></a> [resource\_group\_name](#output\_resource\_group\_name) | The name of the Resource Group where the Front Door Profile was created. |
| <a name="output_resource_guid"></a> [resource\_guid](#output\_resource\_guid) | The UUID of this Front Door Profile which will be sent in the HTTP Header as the X-Azure-FDID attribute. |
