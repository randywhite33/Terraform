## Requirements

No requirements.

## Providers

| Name | Version |
|------|---------|
| <a name="provider_azurerm"></a> [azurerm](#provider\_azurerm) | n/a |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [azurerm_bastion_host.bastion](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/bastion_host) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_copy_paste_enabled"></a> [copy\_paste\_enabled](#input\_copy\_paste\_enabled) | (Optional) refer to resource provider for usage | `bool` | `true` | no |
| <a name="input_file_copy_enabled"></a> [file\_copy\_enabled](#input\_file\_copy\_enabled) | (Optional) refer to resource provider for usage | `bool` | `false` | no |
| <a name="input_ip_configuration"></a> [ip\_configuration](#input\_ip\_configuration) | (Required)ip\_configuration\_block | <pre>object({<br>    name                 = string<br>    subnet_id            = string<br>    public_ip_address_id = string<br>  })</pre> | n/a | yes |
| <a name="input_ip_connect_enabled"></a> [ip\_connect\_enabled](#input\_ip\_connect\_enabled) | (Optional) refer to resource provider for usage | `bool` | `false` | no |
| <a name="input_location"></a> [location](#input\_location) | (Required) Define the region where the resource will be created | `string` | n/a | yes |
| <a name="input_name"></a> [name](#input\_name) | (Required) Name of the Bastion | `string` | n/a | yes |
| <a name="input_resource_group_name"></a> [resource\_group\_name](#input\_resource\_group\_name) | (Required) Name of the resource group where to create the Bastion | `string` | n/a | yes |
| <a name="input_scale_units"></a> [scale\_units](#input\_scale\_units) | (Optional) refer to resource provider for usage | `number` | `null` | no |
| <a name="input_shareable_link_enabled"></a> [shareable\_link\_enabled](#input\_shareable\_link\_enabled) | (Optional) refer to resource provider for usage | `bool` | `false` | no |
| <a name="input_sku"></a> [sku](#input\_sku) | (Required) SKU of Bastion | `string` | `"Standard"` | no |
| <a name="input_tags"></a> [tags](#input\_tags) | (Required) map of tags for the deployment | `map(any)` | n/a | yes |
| <a name="input_tunneling_enabled"></a> [tunneling\_enabled](#input\_tunneling\_enabled) | (Optional) refer to resource provider for usage | `bool` | `true` | no |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_dns_name"></a> [dns\_name](#output\_dns\_name) | The DNS hostname of the deployed Bastion Host. |
| <a name="output_id"></a> [id](#output\_id) | The id of the deployed Bastion Host. |
| <a name="output_name"></a> [name](#output\_name) | The name of the deployed Bastion Host. |
