## Requirements

No requirements.

## Providers

| Name | Version |
|------|---------|
| <a name="provider_azurerm"></a> [azurerm](#provider\_azurerm) | n/a |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [azurerm_firewall.fw](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/firewall) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_fw_name"></a> [fw\_name](#input\_fw\_name) | Firewall name | `string` | n/a | yes |
| <a name="input_location"></a> [location](#input\_location) | Location where Firewall will be deployed | `string` | n/a | yes |
| <a name="input_pip_id"></a> [pip\_id](#input\_pip\_id) | Firewall public IP ID | `string` | n/a | yes |
| <a name="input_resource_group"></a> [resource\_group](#input\_resource\_group) | Resource group name | `string` | n/a | yes |
| <a name="input_secondary_firewall_public_ips"></a> [secondary\_firewall\_public\_ips](#input\_secondary\_firewall\_public\_ips) | Secondary Firewall Public IPs | <pre>map(object({<br>    name = string<br>    id   = string<br>  }))</pre> | `{}` | no |
| <a name="input_sku_name"></a> [sku\_name](#input\_sku\_name) | SKU name. Valid values are AZFW\_Hub and AZFW\_VNet. | `string` | `"AZFW_VNet"` | no |
| <a name="input_sku_tier"></a> [sku\_tier](#input\_sku\_tier) | SKU tier. Valid values are Standard and Premium. | `string` | n/a | yes |
| <a name="input_subnet_id"></a> [subnet\_id](#input\_subnet\_id) | Subnet ID | `string` | n/a | yes |
| <a name="input_tags"></a> [tags](#input\_tags) | Tags to apply to the firewall and public IP | `map(string)` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_fw_private_ip"></a> [fw\_private\_ip](#output\_fw\_private\_ip) | n/a |
| <a name="output_id"></a> [id](#output\_id) | n/a |
| <a name="output_name"></a> [name](#output\_name) | n/a |
