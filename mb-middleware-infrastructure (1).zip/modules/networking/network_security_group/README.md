## Requirements

No requirements.

## Providers

| Name | Version |
|------|---------|
| <a name="provider_azurerm"></a> [azurerm](#provider\_azurerm) | n/a |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [azurerm_network_security_group.nsg](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_group) | resource |
| [azurerm_subnet_network_security_group_association.nsg_association](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/subnet_network_security_group_association) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_location"></a> [location](#input\_location) | (Required) Azure deployment location. This are azurerm api values. | `string` | `"eastus"` | no |
| <a name="input_name"></a> [name](#input\_name) | (Required) Specifies the name of the NSG. Changing this forces a new resource to be created. | `string` | n/a | yes |
| <a name="input_resource_group_name"></a> [resource\_group\_name](#input\_resource\_group\_name) | (Required) Name of Resource Group where resources will be created. | `string` | n/a | yes |
| <a name="input_security_rules"></a> [security\_rules](#input\_security\_rules) | (Optional) List of objects containing network security rules. | <pre>list(object({<br>    name                       = string,<br>    priority                   = number,<br>    direction                  = string,<br>    access                     = string,<br>    protocol                   = string,<br>    source_address_prefix      = string,<br>    source_port_range          = string,<br>    destination_address_prefix = string,<br>    destination_port_range     = optional(string, null)<br>    destination_port_ranges    = optional(list(string), null)<br>  }))</pre> | `null` | no |
| <a name="input_subnet_ids"></a> [subnet\_ids](#input\_subnet\_ids) | (Optional) List of IDs of the Subnet to associate the NSG with. | `list(any)` | n/a | yes |
| <a name="input_tags"></a> [tags](#input\_tags) | (Required) Tags to be added to resource during creation/update. | `map(any)` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_id"></a> [id](#output\_id) | n/a |
| <a name="output_name"></a> [name](#output\_name) | n/a |
| <a name="output_resource_group_name"></a> [resource\_group\_name](#output\_resource\_group\_name) | n/a |
