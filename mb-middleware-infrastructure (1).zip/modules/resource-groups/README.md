## Requirements

No requirements.

## Providers

| Name | Version |
|------|---------|
| <a name="provider_azurerm"></a> [azurerm](#provider\_azurerm) | n/a |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [azurerm_resource_group.this](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/resource_group) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_application_name"></a> [application\_name](#input\_application\_name) | (Required) Application Name | `string` | n/a | yes |
| <a name="input_environment"></a> [environment](#input\_environment) | (Required) Which Enviornment is this resource deployed | `string` | n/a | yes |
| <a name="input_location"></a> [location](#input\_location) | (Required) Azure Region and Code | <pre>object({<br>    azure_region  = string<br>    location_code = string<br>  })</pre> | n/a | yes |
| <a name="input_slug"></a> [slug](#input\_slug) | (Optional) A slug to use for the resource group name. | `string` | `""` | no |
| <a name="input_tags"></a> [tags](#input\_tags) | (Required) Azure Tags | `any` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_location"></a> [location](#output\_location) | n/a |
| <a name="output_name"></a> [name](#output\_name) | n/a |
