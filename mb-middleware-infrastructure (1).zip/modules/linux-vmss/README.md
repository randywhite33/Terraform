## Requirements

No requirements.

## Providers

| Name | Version |
|------|---------|
| <a name="provider_azurerm"></a> [azurerm](#provider\_azurerm) | n/a |
| <a name="provider_tls"></a> [tls](#provider\_tls) | n/a |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [azurerm_linux_virtual_machine_scale_set.this](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/linux_virtual_machine_scale_set) | resource |
| [azurerm_virtual_machine_scale_set_extension.AzureMonitorLinuxAgent](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/virtual_machine_scale_set_extension) | resource |
| [azurerm_virtual_machine_scale_set_extension.AzurePolicyforLinux](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/virtual_machine_scale_set_extension) | resource |
| [azurerm_virtual_machine_scale_set_extension.ChangeTracking-Linux](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/virtual_machine_scale_set_extension) | resource |
| [azurerm_virtual_machine_scale_set_extension.DependencyAgentLinux](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/virtual_machine_scale_set_extension) | resource |
| [azurerm_virtual_machine_scale_set_extension.GuestHealthLinuxAgent](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/virtual_machine_scale_set_extension) | resource |
| [azurerm_virtual_machine_scale_set_extension.MDE_Linux](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/virtual_machine_scale_set_extension) | resource |
| [azurerm_virtual_machine_scale_set_extension.OmsAgentForLinux](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/virtual_machine_scale_set_extension) | resource |
| [tls_private_key.ssh](https://registry.terraform.io/providers/hashicorp/tls/latest/docs/resources/private_key) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_application_name"></a> [application\_name](#input\_application\_name) | (Required) Application Name | `string` | n/a | yes |
| <a name="input_environment"></a> [environment](#input\_environment) | (Required) Which Enviornment is this resource deployed | `string` | n/a | yes |
| <a name="input_location"></a> [location](#input\_location) | (Required) Azure Region and Code | <pre>object({<br>    azure_region  = string<br>    location_code = string<br>  })</pre> | n/a | yes |
| <a name="input_network_profile_ip_configuration_name"></a> [network\_profile\_ip\_configuration\_name](#input\_network\_profile\_ip\_configuration\_name) | The name of the network profile's IP configuration | `string` | `"vmss-ip-config"` | no |
| <a name="input_os_storage_sku"></a> [os\_storage\_sku](#input\_os\_storage\_sku) | The Storage SKU for the Operating System Drive | `string` | n/a | yes |
| <a name="input_plan_name"></a> [plan\_name](#input\_plan\_name) | Paid VM image plan name | `string` | n/a | yes |
| <a name="input_plan_product"></a> [plan\_product](#input\_plan\_product) | Paid VM image plan product | `string` | n/a | yes |
| <a name="input_plan_publisher"></a> [plan\_publisher](#input\_plan\_publisher) | Paid VM image plan publisher | `string` | n/a | yes |
| <a name="input_resource_group_name"></a> [resource\_group\_name](#input\_resource\_group\_name) | n/a | `string` | n/a | yes |
| <a name="input_source_image_id"></a> [source\_image\_id](#input\_source\_image\_id) | The ID of the source VM image used to create the virtual machines in the VM scale set | `string` | n/a | yes |
| <a name="input_subnet_id"></a> [subnet\_id](#input\_subnet\_id) | ID of subnet where VMSS will be deployed | `string` | n/a | yes |
| <a name="input_tags"></a> [tags](#input\_tags) | (Required) Azure Tags | `any` | n/a | yes |
| <a name="input_vmss_admin_username"></a> [vmss\_admin\_username](#input\_vmss\_admin\_username) | The username of the administrator on the virtual machines in the VM scale set | `string` | `"azureuser"` | no |
| <a name="input_vmss_extension_versions"></a> [vmss\_extension\_versions](#input\_vmss\_extension\_versions) | To Centralize and Organize Linux VMSS Extension Versions | <pre>object({<br>    AzureMonitorLinuxAgent = string<br>    ChangeTracking-Linux   = string<br>    ConfigurationForLinux  = string<br>    CustomScript           = string<br>    DependencyAgentLinux   = string<br>    MDE_Linux              = string<br>    GuestHealthLinuxAgent  = string<br>    OmsAgentForLinux       = string ## Azure Log Analytics Agent to be depricated in August 2024<br>  })</pre> | <pre>{<br>  "AzureMonitorLinuxAgent": "1.29",<br>  "ChangeTracking-Linux": "2.20",<br>  "ConfigurationForLinux": "1.26",<br>  "CustomScript": "2.1",<br>  "DependencyAgentLinux": "9.10",<br>  "GuestHealthLinuxAgent": "1.0",<br>  "MDE_Linux": "1.0",<br>  "OmsAgentForLinux": "1.17"<br>}</pre> | no |
| <a name="input_vmss_instances"></a> [vmss\_instances](#input\_vmss\_instances) | The number of virtual machines in the VM scale set | `number` | `1` | no |
| <a name="input_vmss_sku"></a> [vmss\_sku](#input\_vmss\_sku) | The SKU of the virtual machines that will be used in the VM scale set | `string` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_identity"></a> [identity](#output\_identity) | System assigned identity which is used by master components |
| <a name="output_tls_private_key"></a> [tls\_private\_key](#output\_tls\_private\_key) | n/a |
| <a name="output_vmss_id"></a> [vmss\_id](#output\_vmss\_id) | ID of the VMSS |
