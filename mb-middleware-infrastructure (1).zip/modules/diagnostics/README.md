## Requirements

No requirements.

## Providers

| Name | Version |
|------|---------|
| <a name="provider_azurerm"></a> [azurerm](#provider\_azurerm) | n/a |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [azurerm_monitor_diagnostic_setting.diag_settings](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/monitor_diagnostic_setting) | resource |
| [azurerm_monitor_diagnostic_categories.log_categories](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/data-sources/monitor_diagnostic_categories) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_category_log_types"></a> [category\_log\_types](#input\_category\_log\_types) | A list of strings containing the log types to enable. The Azure API doesn't accept category groups for log types, so use 'all' for all logs. | `list(string)` | <pre>[<br>  "all"<br>]</pre> | no |
| <a name="input_environment"></a> [environment](#input\_environment) | (Required) The environment, used to point to the right Log Analytics | `string` | n/a | yes |
| <a name="input_location"></a> [location](#input\_location) | (Required) Specifies the supported Azure location where to create the resource. Changing this forces a new resource to be created. | `string` | n/a | yes |
| <a name="input_metric_log_types"></a> [metric\_log\_types](#input\_metric\_log\_types) | A list of strings containing the metric types to enable. Use 'AllMetrics' for the category group or 'all' to individually choose all logs. | `list(string)` | <pre>[<br>  "all"<br>]</pre> | no |
| <a name="input_name"></a> [name](#input\_name) | (Required) The name of the diagnostic setting. | `string` | n/a | yes |
| <a name="input_target_resource_id"></a> [target\_resource\_id](#input\_target\_resource\_id) | (Required) The target resource to apply diagnostics to. | `string` | n/a | yes |

## Outputs

No outputs.
