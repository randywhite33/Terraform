## Requirements

No requirements.

## Providers

| Name | Version |
|------|---------|
| <a name="provider_azurerm"></a> [azurerm](#provider\_azurerm) | n/a |

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_standard_nsg"></a> [standard\_nsg](#module\_standard\_nsg) | ../../modules/nsgs | n/a |

## Resources

| Name | Type |
|------|------|
| [azurerm_subnet.special](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/subnet) | resource |
| [azurerm_subnet.standard](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/subnet) | resource |
| [azurerm_virtual_network.this](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/virtual_network) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_application_name"></a> [application\_name](#input\_application\_name) | (Required) Application Name | `string` | n/a | yes |
| <a name="input_cidr_range"></a> [cidr\_range](#input\_cidr\_range) | (Required) Networking Range of the VNet | <pre>object({<br>    ipv4_address = string<br>    subnet_mask  = string<br>  })</pre> | n/a | yes |
| <a name="input_environment"></a> [environment](#input\_environment) | (Required) Which Enviornment is this resource deployed | `string` | n/a | yes |
| <a name="input_location"></a> [location](#input\_location) | (Required) Azure Region and Code | <pre>object({<br>    azure_region  = string<br>    location_code = string<br>  })</pre> | n/a | yes |
| <a name="input_resource_group_name"></a> [resource\_group\_name](#input\_resource\_group\_name) | (Required) Azure Resource Group Name | `string` | n/a | yes |
| <a name="input_special_subnets"></a> [special\_subnets](#input\_special\_subnets) | Special Subnets within this VNet | <pre>map(object({<br>    cidr_range = object({<br>      ipv4_address = string<br>      subnet_mask  = string<br>    })<br>  }))</pre> | n/a | yes |
| <a name="input_standard_subnets"></a> [standard\_subnets](#input\_standard\_subnets) | Standard Subnets within this VNet | <pre>map(object({<br>    cidr_range = object({<br>      ipv4_address = string<br>      subnet_mask  = string<br>    })<br>    nsg_template = string<br>  }))</pre> | n/a | yes |
| <a name="input_tags"></a> [tags](#input\_tags) | (Required) Azure Tags | `any` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_id"></a> [id](#output\_id) | The ID of the Virtual Network |
| <a name="output_name"></a> [name](#output\_name) | The name of the Virtual Network |
