## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | ~> 1.6.0 |
| <a name="requirement_azurerm"></a> [azurerm](#requirement\_azurerm) | ~> 3.76.0 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_azurerm"></a> [azurerm](#provider\_azurerm) | 3.76.0 |

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_frontdoor_profile"></a> [frontdoor\_profile](#module\_frontdoor\_profile) | ../../modules/frontdoor_profile | n/a |

## Resources

| Name | Type |
|------|------|
| [azurerm_management_lock.resource-group-level](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/management_lock) | resource |
| [azurerm_monitor_diagnostic_setting.this](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/monitor_diagnostic_setting) | resource |
| [azurerm_resource_group.this](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/resource_group) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_frontdoor_name"></a> [frontdoor\_name](#input\_frontdoor\_name) | Specifies the name of the Front Door Profile. Changing this forces a new resource to be created. | `string` | n/a | yes |
| <a name="input_global_settings"></a> [global\_settings](#input\_global\_settings) | Used for tagging and naming standards. | <pre>object({<br>    owner               = string<br>    environment         = string<br>    application_name    = string<br>    eai_id              = string<br>    eoi_level           = string<br>    data_classification = string<br>  })</pre> | n/a | yes |
| <a name="input_lock_resource_group"></a> [lock\_resource\_group](#input\_lock\_resource\_group) | Setting this to true will lock all resource groups in the configuration. | `bool` | `true` | no |
| <a name="input_workspace_id"></a> [workspace\_id](#input\_workspace\_id) | The ID of the Log Analytics Workspace to save the data in. Expected format: /subscriptions/c123456c-12d3-12bd-1c23-b123456a7890/resourceGroups/rg-resource-group-name/providers/Microsoft.OperationalInsights/workspaces/log-workspace-name | `string` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_management_lock"></a> [management\_lock](#output\_management\_lock) | n/a |
| <a name="output_profile_id"></a> [profile\_id](#output\_profile\_id) | The ID of this Front Door Profile. |
| <a name="output_profile_name"></a> [profile\_name](#output\_profile\_name) | The name of the Front Door Profile. |
| <a name="output_profile_resource_guid"></a> [profile\_resource\_guid](#output\_profile\_resource\_guid) | The UUID of this Front Door Profile which will be sent in the HTTP Header as the X-Azure-FDID attribute. |
| <a name="output_resource_group_name"></a> [resource\_group\_name](#output\_resource\_group\_name) | The name of the Resource Group where the Front Door Profile was created. |
