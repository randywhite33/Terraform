# Manu Bank Stack to deploy a multi-hub network architecture

This module is designed to  simplify the creation of multi-region hub networks in Azure. It will create a number of virtual networks and subnets, and optionally peer them together in a mesh topology. In addition, a NAT gateway can also be deployed if needed. 

[![Build Status](https://dev.azure.com/ManufacturersBank/Infrastructure/_apis/build/status%2Ftest_pr_check?branchName=main)](https://dev.azure.com/ManufacturersBank/Infrastructure/_build/latest?definitionId=37&branchName=main)