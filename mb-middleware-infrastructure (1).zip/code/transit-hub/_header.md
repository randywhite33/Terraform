# Manu Bank Stack to deploy a network architecture for sdwan deployment
