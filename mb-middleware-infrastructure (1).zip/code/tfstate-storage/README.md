## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | ~> 1.6.5 |
| <a name="requirement_azurerm"></a> [azurerm](#requirement\_azurerm) | ~> 3.76.0 |
| <a name="requirement_null"></a> [null](#requirement\_null) | ~> 3.2.0 |
| <a name="requirement_time"></a> [time](#requirement\_time) | ~> 0.10.0 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_azurerm"></a> [azurerm](#provider\_azurerm) | ~> 3.76.0 |
| <a name="provider_time"></a> [time](#provider\_time) | ~> 0.10.0 |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [azurerm_key_vault.tfstate](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/key_vault) | resource |
| [azurerm_key_vault_access_policy.admin](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/key_vault_access_policy) | resource |
| [azurerm_key_vault_access_policy.tfstate](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/key_vault_access_policy) | resource |
| [azurerm_key_vault_key.tfstate_cmk](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/key_vault_key) | resource |
| [azurerm_log_analytics_storage_insights.tfstate](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/log_analytics_storage_insights) | resource |
| [azurerm_log_analytics_workspace.this](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/log_analytics_workspace) | resource |
| [azurerm_resource_group.tfstate](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/resource_group) | resource |
| [azurerm_role_assignment.storage_container](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/role_assignment) | resource |
| [azurerm_role_assignment.storage_queue](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/role_assignment) | resource |
| [azurerm_storage_account.tfstate](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/storage_account) | resource |
| [azurerm_storage_account_customer_managed_key.tfstate_cmk](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/storage_account_customer_managed_key) | resource |
| [azurerm_storage_container.tfstate](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/storage_container) | resource |
| [time_static.update_encryption_keys_expiration](https://registry.terraform.io/providers/hashicorp/time/latest/docs/resources/static) | resource |
| [azurerm_client_config.current](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/data-sources/client_config) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_global_settings"></a> [global\_settings](#input\_global\_settings) | n/a | <pre>object({<br>    owner               = string<br>    environment         = string<br>    application_name    = string<br>    eai_id              = string<br>    eoi_level           = string<br>    data_classification = string<br>  })</pre> | n/a | yes |
| <a name="input_key_vault_details"></a> [key\_vault\_details](#input\_key\_vault\_details) | (Required) Key Vault Details | <pre>object({<br>    application_name              = string<br>    location_map_key              = string<br>    sku                           = string<br>    enabled_for_disk_encryption   = bool<br>    purge_protection_enabled      = optional(bool, true)<br>    public_network_access_enabled = optional(bool, false)<br>  })</pre> | n/a | yes |
| <a name="input_resource_group_details"></a> [resource\_group\_details](#input\_resource\_group\_details) | (Required) Resource Group Name and Location | <pre>object({<br>    name             = string<br>    location_map_key = string<br>  })</pre> | n/a | yes |
| <a name="input_storage_account_details"></a> [storage\_account\_details](#input\_storage\_account\_details) | n/a | <pre>object({<br>    application_name                = string<br>    location_map_key                = string<br>    allow_nested_items_to_be_public = optional(bool, false)<br>    public_network_access_enabled   = optional(bool, false)<br>  })</pre> | n/a | yes |
| <a name="input_update_encryption_keys_expiration"></a> [update\_encryption\_keys\_expiration](#input\_update\_encryption\_keys\_expiration) | Value used to determine if CMK needs to be rotated. Change this Value to Update | `string` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_tfstate_resource_group_name"></a> [tfstate\_resource\_group\_name](#output\_tfstate\_resource\_group\_name) | n/a |
| <a name="output_tfstate_storage_account_name"></a> [tfstate\_storage\_account\_name](#output\_tfstate\_storage\_account\_name) | n/a |
