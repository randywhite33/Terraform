<!-- BEGIN_TF_DOCS -->
# Manu Bank Stack to deploy a multi-hub network architecture

This module is designed to  simplify the creation of multi-region hub networks in Azure. It will create a number of virtual networks and subnets, and optionally peer them together in a mesh topology. In addition, a NAT gateway can also be deployed if needed.

## Documentation
<!-- markdownlint-disable MD033 -->

## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | ~> 1.6.5 |
| <a name="requirement_azurerm"></a> [azurerm](#requirement\_azurerm) | ~> 3.76.0 |

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_azurebastionsubnet"></a> [azurebastionsubnet](#module\_azurebastionsubnet) | ../../modules/networking/subnet | n/a |
| <a name="module_azurebastionsubnet_nsg"></a> [azurebastionsubnet\_nsg](#module\_azurebastionsubnet\_nsg) | ../../modules/networking/network_security_group | n/a |
| <a name="module_azurebastionsubnet_nsg_diagnostics"></a> [azurebastionsubnet\_nsg\_diagnostics](#module\_azurebastionsubnet\_nsg\_diagnostics) | ../../modules/diagnostics | n/a |
| <a name="module_azurefirewallsubnet"></a> [azurefirewallsubnet](#module\_azurefirewallsubnet) | ../../modules/networking/subnet | n/a |
| <a name="module_bastion"></a> [bastion](#module\_bastion) | ../../modules/terraform-azurerm-bastionhost | n/a |
| <a name="module_bastion_diagnostics"></a> [bastion\_diagnostics](#module\_bastion\_diagnostics) | ../../modules/diagnostics | n/a |
| <a name="module_bastion_pip"></a> [bastion\_pip](#module\_bastion\_pip) | ../../modules/networking/public_ip_address | n/a |
| <a name="module_bastion_pip_diagnostics"></a> [bastion\_pip\_diagnostics](#module\_bastion\_pip\_diagnostics) | ../../modules/diagnostics | n/a |
| <a name="module_bastion_resource_group"></a> [bastion\_resource\_group](#module\_bastion\_resource\_group) | ../../modules/resource-groups | n/a |
| <a name="module_firewall"></a> [firewall](#module\_firewall) | ../../modules/terraform-module_firewall | n/a |
| <a name="module_firewall_diagnostics"></a> [firewall\_diagnostics](#module\_firewall\_diagnostics) | ../../modules/diagnostics | n/a |
| <a name="module_firewall_pip"></a> [firewall\_pip](#module\_firewall\_pip) | ../../modules/networking/public_ip_address | n/a |
| <a name="module_firewall_pip_diagnostics"></a> [firewall\_pip\_diagnostics](#module\_firewall\_pip\_diagnostics) | ../../modules/diagnostics | n/a |
| <a name="module_firewall_policy_resource_group"></a> [firewall\_policy\_resource\_group](#module\_firewall\_policy\_resource\_group) | ../../modules/resource-groups | n/a |
| <a name="module_firewall_resource_group"></a> [firewall\_resource\_group](#module\_firewall\_resource\_group) | ../../modules/resource-groups | n/a |
| <a name="module_gatewaysubnet"></a> [gatewaysubnet](#module\_gatewaysubnet) | ../../modules/networking/subnet | n/a |
| <a name="module_hub_public_ip_prefix_diagnostics"></a> [hub\_public\_ip\_prefix\_diagnostics](#module\_hub\_public\_ip\_prefix\_diagnostics) | ../../modules/diagnostics | n/a |
| <a name="module_integration_nsg_diagnostics"></a> [integration\_nsg\_diagnostics](#module\_integration\_nsg\_diagnostics) | ../../modules/diagnostics | n/a |
| <a name="module_integration_subnet"></a> [integration\_subnet](#module\_integration\_subnet) | ../../modules/networking/subnet | n/a |
| <a name="module_integration_subnet_nsg"></a> [integration\_subnet\_nsg](#module\_integration\_subnet\_nsg) | ../../modules/networking/network_security_group | n/a |
| <a name="module_nat_gateway_pippf_diagnostics"></a> [nat\_gateway\_pippf\_diagnostics](#module\_nat\_gateway\_pippf\_diagnostics) | ../../modules/diagnostics | n/a |
| <a name="module_pe_subnet"></a> [pe\_subnet](#module\_pe\_subnet) | ../../modules/networking/subnet | n/a |
| <a name="module_pe_subnet_nsg"></a> [pe\_subnet\_nsg](#module\_pe\_subnet\_nsg) | ../../modules/networking/network_security_group | n/a |
| <a name="module_pe_subnet_nsg_diagnostics"></a> [pe\_subnet\_nsg\_diagnostics](#module\_pe\_subnet\_nsg\_diagnostics) | ../../modules/diagnostics | n/a |
| <a name="module_private_dns_resource_group"></a> [private\_dns\_resource\_group](#module\_private\_dns\_resource\_group) | ../../modules/resource-groups | n/a |
| <a name="module_private_dns_zones"></a> [private\_dns\_zones](#module\_private\_dns\_zones) | ../../modules/terraform-azurerm-privatednszone | n/a |
| <a name="module_route_table"></a> [route\_table](#module\_route\_table) | ../../modules/terraform-module_route-table | n/a |
| <a name="module_virtual_network"></a> [virtual\_network](#module\_virtual\_network) | ../../modules/networking/virtual_network | n/a |
| <a name="module_virtual_network_diagnostics"></a> [virtual\_network\_diagnostics](#module\_virtual\_network\_diagnostics) | ../../modules/diagnostics | n/a |
| <a name="module_vm_subnet"></a> [vm\_subnet](#module\_vm\_subnet) | ../../modules/networking/subnet | n/a |
| <a name="module_vm_subnet_nsg"></a> [vm\_subnet\_nsg](#module\_vm\_subnet\_nsg) | ../../modules/networking/network_security_group | n/a |
| <a name="module_vm_subnet_nsg_diagnostics"></a> [vm\_subnet\_nsg\_diagnostics](#module\_vm\_subnet\_nsg\_diagnostics) | ../../modules/diagnostics | n/a |
| <a name="module_vmss_subnet"></a> [vmss\_subnet](#module\_vmss\_subnet) | ../../modules/networking/subnet | n/a |
| <a name="module_vmss_subnet_nsg"></a> [vmss\_subnet\_nsg](#module\_vmss\_subnet\_nsg) | ../../modules/networking/network_security_group | n/a |
| <a name="module_vmss_subnet_nsg_diagnostics"></a> [vmss\_subnet\_nsg\_diagnostics](#module\_vmss\_subnet\_nsg\_diagnostics) | ../../modules/diagnostics | n/a |

<!-- markdownlint-disable MD013 -->
## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_global_settings"></a> [global\_settings](#input\_global\_settings) | n/a | <pre>object({<br>    owner               = string<br>    environment         = string<br>    application_name    = string<br>    eai_id              = string<br>    eoi_level           = string<br>    data_classification = string<br>  })</pre> | n/a | yes |
| <a name="input_log_analytics_workspace_id"></a> [log\_analytics\_workspace\_id](#input\_log\_analytics\_workspace\_id) | The ID of the Log Analytics Workspace that the Firewalls associated with the Firewall Policy will send their logs to. | `string` | n/a | yes |
| <a name="input_address_spaces"></a> [address\_spaces](#input\_address\_spaces) | The address spaces to use for each region. | `list(string)` | <pre>[<br>  "172.19.0.0/22",<br>  "172.19.128.0/22"<br>]</pre> | no |
| <a name="input_azurebastionsubnet_address_prefix"></a> [azurebastionsubnet\_address\_prefix](#input\_azurebastionsubnet\_address\_prefix) | abc123 | `list(string)` | <pre>[<br>  "172.19.0.128/26",<br>  "172.19.128.128/26"<br>]</pre> | no |
| <a name="input_azurefirewallsubnet_address_prefix"></a> [azurefirewallsubnet\_address\_prefix](#input\_azurefirewallsubnet\_address\_prefix) | abc123 | `list(string)` | <pre>[<br>  "172.19.0.64/26",<br>  "172.19.128.64/26"<br>]</pre> | no |
| <a name="input_enable_nat_gateway"></a> [enable\_nat\_gateway](#input\_enable\_nat\_gateway) | Should a NAT Gateway be deployed for egress? | `bool` | `false` | no |
| <a name="input_firewall_threat_intel_mode"></a> [firewall\_threat\_intel\_mode](#input\_firewall\_threat\_intel\_mode) | The operation mode for threat intelligence-based filtering. Possible values are: Off, Alert and Deny. Defaults to Alert. | `string` | `"Alert"` | no |
| <a name="input_gatewaysubnet_address_prefix"></a> [gatewaysubnet\_address\_prefix](#input\_gatewaysubnet\_address\_prefix) | abc123 | `list(string)` | <pre>[<br>  "172.19.0.32/27",<br>  "172.19.128.32/27"<br>]</pre> | no |
| <a name="input_integration_subnet_address_prefix"></a> [integration\_subnet\_address\_prefix](#input\_integration\_subnet\_address\_prefix) | abc123 | `list(string)` | <pre>[<br>  "172.19.0.0/27",<br>  "172.19.128.0/27"<br>]</pre> | no |
| <a name="input_mesh_peering_enabled"></a> [mesh\_peering\_enabled](#input\_mesh\_peering\_enabled) | Should mesh peering be enabled? Has no effect in single region deployments. | `bool` | `true` | no |
| <a name="input_pe_subnet_address_prefix"></a> [pe\_subnet\_address\_prefix](#input\_pe\_subnet\_address\_prefix) | abc123 | `list(string)` | <pre>[<br>  "172.19.2.0/24",<br>  "172.19.130.0/24"<br>]</pre> | no |
| <a name="input_private_dns_zones"></a> [private\_dns\_zones](#input\_private\_dns\_zones) | A list of private dns zones to create. Will be created as global objects in the primary region. | `list(string)` | <pre>[<br>  "privatelink.blob.core.windows.net",<br>  "privatelink.table.core.windows.net",<br>  "privatelink.queue.core.windows.net",<br>  "privatelink.file.core.windows.net",<br>  "privatelink.web.core.windows.net",<br>  "privatelink.documents.azure.com",<br>  "privatelink.mongo.cosmos.azure.com",<br>  "privatelink.cassandra.cosmos.azure.com",<br>  "privatelink.gremlin.cosmos.azure.com",<br>  "privatelink.table.cosmos.azure.com",<br>  "privatelink.vaultcore.azure.net",<br>  "privatelink.managedhsm.azure.net",<br>  "privatelink.azurecr.io",<br>  "privatelink.siterecovery.windowsazure.com",<br>  "privatelink.servicebus.windows.net",<br>  "privatelink.monitor.azure.com",<br>  "privatelink.eastus.azmk8s.io",<br>  "privatelink.westus3.azmk8s.io",<br>  "privatelink.eus.backup.windowsazure.com",<br>  "privatelink.wus3.backup.windowsazure.com"<br>]</pre> | no |
| <a name="input_regions"></a> [regions](#input\_regions) | The list of regions where the landing zone resources will be deployed. | `list(string)` | <pre>[<br>  "eastus",<br>  "westus3"<br>]</pre> | no |
| <a name="input_vm_subnet_address_prefix"></a> [vm\_subnet\_address\_prefix](#input\_vm\_subnet\_address\_prefix) | abc123 | `list(string)` | <pre>[<br>  "172.19.1.0/25",<br>  "172.19.129.0/25"<br>]</pre> | no |
| <a name="input_vmss_subnet_address_prefix"></a> [vmss\_subnet\_address\_prefix](#input\_vmss\_subnet\_address\_prefix) | abc123 | `list(string)` | <pre>[<br>  "172.19.1.128/25",<br>  "172.19.129.128/25"<br>]</pre> | no |

## Resources

| Name | Type |
|------|------|
| [azurerm_firewall_policy.fwpolicy](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/firewall_policy) | resource |
| [azurerm_firewall_policy_rule_collection_group.allow_internal](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/firewall_policy_rule_collection_group) | resource |
| [azurerm_nat_gateway.this](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/nat_gateway) | resource |
| [azurerm_nat_gateway_public_ip_prefix_association.azurefirewallsubnet](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/nat_gateway_public_ip_prefix_association) | resource |
| [azurerm_public_ip_prefix.hub](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/public_ip_prefix) | resource |
| [azurerm_public_ip_prefix.nat_gateway](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/public_ip_prefix) | resource |
| [azurerm_subnet_nat_gateway_association.azurefirewallsubnet](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/subnet_nat_gateway_association) | resource |
| [azurerm_subnet_route_table_association.integration_subnet](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/subnet_route_table_association) | resource |
| [azurerm_subnet_route_table_association.pe_subnet](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/subnet_route_table_association) | resource |
| [azurerm_subnet_route_table_association.vm_subnet](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/subnet_route_table_association) | resource |
| [azurerm_subnet_route_table_association.vmss_subnet](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/subnet_route_table_association) | resource |
| [azurerm_virtual_network_peering.hub_peering](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/virtual_network_peering) | resource |

## Outputs

No outputs.

<!-- markdownlint-enable -->

<!-- END_TF_DOCS -->